import streamlit as st

def page2():
    st.title("Select Analysis Type")

    # Check if data is loaded
    if st.session_state['data'] is None:
        st.warning("Please upload a dataset first.")
        return

    # Button for Correlation Analysis
    if st.button("Correlation Analysis"):
        st.session_state['analysis_type'] = "correlation"
        # Direct to the Correlation Analysis page (you can either rerun or navigate based on your app structure)
        st.session_state['current_page'] = 2  # Assuming page3 is for correlation analysis
        st.rerun()

    # Button for Supervised Learning
    if st.button("Supervised Learning"):
        st.session_state['analysis_type'] = "supervised"
        # Direct to the Supervised Learning page
        st.session_state['current_page'] = 3  # Assuming page4 is for supervised learning
        st.rerun()

    # Button for Unsupervised Learning
    if st.button("Unsupervised Learning"):
        st.session_state['analysis_type'] = "unsupervised"
        # Direct to the Unsupervised Learning page
        st.session_state['current_page'] = 4  # Assuming page5 is for unsupervised learning
        st.rerun()

    # Button for Feature Selection & Visualization (Page 6)
    if st.button("Hypothesis Testing"):
        st.session_state['analysis_type'] = "feature_selection"
        # Direct to the Feature Selection & Visualization page
        st.session_state['current_page'] = 5  # Assuming page6 is for feature selection and visualization
        st.rerun()
