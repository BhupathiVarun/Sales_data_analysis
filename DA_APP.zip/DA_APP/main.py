import sys
sys.path.append("app3/page7_hypothesis_testing.py")  # Make sure the path is correct

import streamlit as st
from page1_upload import page1
from page2_select_analysis import page2
from page3_correlation_analysis import page3
from page4_supervised_learning import page4
from page5_unsupervised_learning import page5
from page6_hypothesis_testing import page6  # Import Page 6
from page7_feature_selection import page7  # Import Page 7

# Initialize session state for dataset and navigation
if 'data' not in st.session_state:
    st.session_state['data'] = None  # To store dataset

if 'current_page' not in st.session_state:
    st.session_state['current_page'] = 0  # Default to the first page

# Define available pages with their corresponding functions
pages = {
    "Upload Dataset": page1,
    "Select Analysis Type": page2,
    "Correlation Analysis": page3,
    "Supervised Learning": page4,
    "Unsupervised Learning": page5,
    "Hypothesis Testing": page6,  # Page 6
    "Feature Selection & Visualization": page7,  # Page 7
}

# Ensure the current_page index is within range
if st.session_state['current_page'] >= len(pages):
    st.session_state['current_page'] = 0  # Reset to the first page

# Sidebar navigation
st.sidebar.title("Navigation")
selected_page_name = st.sidebar.radio(
    "Go to", list(pages.keys()), index=st.session_state['current_page']
)

# Update the current page in session state when a different page is selected in the sidebar
if selected_page_name != list(pages.keys())[st.session_state['current_page']]:
    st.session_state['current_page'] = list(pages.keys()).index(selected_page_name)
    st.rerun()

# Function to move to the next page
def next_page():
    if st.session_state['current_page'] == 0:  # From Page 1, go to Page 2
        st.session_state['current_page'] = 1
    elif st.session_state['current_page'] == 1:  # From Page 2, go to Page 7
        st.session_state['current_page'] = 6
    elif st.session_state['current_page'] < len(pages) - 1:
        st.session_state['current_page'] += 1
    st.rerun()

# Function to move to the previous page
def prev_page():
    if st.session_state['current_page'] in [2, 3, 4, 5, 6]:  # From Pages 3, 4, 5, 6, go back to Page 2
        st.session_state['current_page'] = 1  # Go back to Page 2
    st.rerun()

# Show the selected page content
pages[selected_page_name]()

# Back and Next Buttons at the bottom
col1, col3, col2 = st.columns([1, 2, 1])

with col1:
    # Back button logic
    if st.session_state['current_page'] > 0:
        if st.button("Back"):
            prev_page()

with col2:
    # Next button logic
    # Only show the "Next" button when on Page 1 or Page 2 (as Pages 3, 4, 5, 6 will have "Back" only)
    if st.session_state['current_page'] == 0:  # Only on Page 1
        if st.button("Next"):
            next_page()
    elif st.session_state['current_page'] == 1:  # Only on Page 2
        if st.button("Next"):
            next_page()
