import streamlit as st
import numpy as np
import pandas as pd
from scipy import stats

# Function to perform T-test
def perform_t_test(data1, data2, alpha=0.05):
    t_stat, p_value = stats.ttest_ind(data1, data2)
    return t_stat, p_value

# Function to perform Z-test
def perform_z_test(data1, data2, alpha=0.05):
    mean1, mean2 = np.mean(data1), np.mean(data2)
    std1, std2 = np.std(data1), np.std(data2)
    n1, n2 = len(data1), len(data2)
    
    pooled_std = np.sqrt(((std1**2) / n1) + ((std2**2) / n2))
    z_stat = (mean1 - mean2) / pooled_std
    p_value = 2 * (1 - stats.norm.cdf(np.abs(z_stat)))
    
    return z_stat, p_value

# Function to perform ANOVA
def perform_anova(data1, data2, alpha=0.05):
    f_stat, p_value = stats.f_oneway(data1, data2)
    return f_stat, p_value

# Function to perform Chi-Square test
def perform_chi_square(data1, data2, alpha=0.05):
    contingency_table = pd.crosstab(data1, data2)
    chi2_stat, p_value, dof, expected = stats.chi2_contingency(contingency_table)
    return chi2_stat, p_value

# Function to perform Proportion Test
def perform_proportion_test(successes, trials, pop_proportion=0.5, alpha=0.05):
    sample_proportion = successes / trials
    z_stat = (sample_proportion - pop_proportion) / np.sqrt((pop_proportion * (1 - pop_proportion)) / trials)
    p_value = 2 * (1 - stats.norm.cdf(np.abs(z_stat)))
    return z_stat, p_value

# Main function for the app
def page6():
    st.title('Hypothesis Testing Web App')

    # Fetching the data from session state
    df = st.session_state['data']
    st.write("Loaded Data:", df.head())  # Display the first few rows of the dataset

    # User inputs for test selection
    test_choice = st.selectbox(
        "Select the Hypothesis Test", 
        ["T-test", "Z-test", "ANOVA", "Chi-Square", "Proportion Test"]
    )

    # Choose columns for testing
    column1 = st.selectbox("Select first column for comparison", df.columns)
    
    # For Chi-Square and Proportion Test, we might need categorical data
    if test_choice == "Chi-Square":
        column2 = st.selectbox("Select second categorical column for Chi-Square Test", df.columns)
        data1 = pd.to_numeric(df[column1], errors='coerce').dropna()
        data2 = pd.to_numeric(df[column2], errors='coerce').dropna()

    else:
        column2 = st.selectbox("Select second column for comparison", df.columns)
        data1 = pd.to_numeric(df[column1], errors='coerce').dropna()
        data2 = pd.to_numeric(df[column2], errors='coerce').dropna()

    # Alpha level input
    alpha = st.slider("Select significance level (alpha)", 0.01, 0.10, 0.05)

    # Inputs for Proportion Test
    if test_choice == "Proportion Test":
        successes = st.number_input("Enter the number of successes", min_value=0)
        trials = st.number_input("Enter the total number of trials", min_value=0)
        pop_proportion = st.number_input("Enter the population proportion", value=0.5)

    # Submit button to perform the test
    if st.button("Submit"):
        if test_choice == "T-test":
            t_stat, p_value = perform_t_test(data1, data2, alpha)
            st.write(f"T-statistic: {t_stat}")
            st.write(f"P-value: {p_value}")
            if p_value < alpha:
                st.success("Reject the null hypothesis: There is a significant difference.")
            else:
                st.error("Fail to reject the null hypothesis: No significant difference.")
        
        elif test_choice == "Z-test":
            z_stat, p_value = perform_z_test(data1, data2, alpha)
            st.write(f"Z-statistic: {z_stat}")
            st.write(f"P-value: {p_value}")
            if p_value < alpha:
                st.success("Reject the null hypothesis: There is a significant difference.")
            else:
                st.error("Fail to reject the null hypothesis: No significant difference.")
        
        elif test_choice == "ANOVA":
            f_stat, p_value = perform_anova(data1, data2, alpha)
            st.write(f"F-statistic: {f_stat}")
            st.write(f"P-value: {p_value}")
            if p_value < alpha:
                st.success("Reject the null hypothesis: There is a significant difference.")
            else:
                st.error("Fail to reject the null hypothesis: No significant difference.")
        
        elif test_choice == "Chi-Square":
            chi2_stat, p_value = perform_chi_square(data1, data2, alpha)
            st.write(f"Chi-Square statistic: {chi2_stat}")
            st.write(f"P-value: {p_value}")
            if p_value < alpha:
                st.success("Reject the null hypothesis: There is a significant association between the variables.")
            else:
                st.error("Fail to reject the null hypothesis: No significant association.")

        elif test_choice == "Proportion Test":
            z_stat, p_value = perform_proportion_test(successes, trials, pop_proportion, alpha)
            st.write(f"Z-statistic: {z_stat}")
            st.write(f"P-value: {p_value}")
            if p_value < alpha:
                st.success("Reject the null hypothesis: The sample proportion is significantly different.")
            else:
                st.error("Fail to reject the null hypothesis: No significant difference.")
