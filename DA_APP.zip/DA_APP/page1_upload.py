import streamlit as st
import pandas as pd
import plotly.graph_objects as go

def page1():
    st.title("Upload Dataset")

    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    if uploaded_file:
        # Load the dataset into session state
        st.session_state['data'] = pd.read_csv(uploaded_file, low_memory=False)
        st.write("Dataset Preview:")
        st.write(st.session_state['data'].head(7))

        # Show the number of rows and columns
        num_rows, num_cols = st.session_state['data'].shape
        st.write(f"Dataset contains {num_rows} rows and {num_cols} columns.")

        # Group columns by their data types
        dtype_groups = st.session_state['data'].dtypes.groupby(st.session_state['data'].dtypes).apply(
            lambda x: x.index.tolist()).to_dict()

        # Convert the dtype_groups dictionary into a format suitable for a table
        dtype_table = []
        for dtype, columns in dtype_groups.items():
            dtype_table.append([dtype, ", ".join(columns)])  # Joining column names as a comma-separated string

        
        # Display the dtype table
        st.subheader("Columns Grouped by Data Types")
        dtype_df = pd.DataFrame(dtype_table, columns=["Data Type", "Columns"])
        st.write(dtype_df)
        df = st.session_state['data'].copy()
        unique_info = []

        for column in df.columns:
            nunique = df[column].nunique()
            values = df[column].unique()
            # Convert the unique values to a string
            unique_values_str = ', '.join(map(str, values))  # Join unique values into a string
            unique_info.append({
                'Column': column,
                'Unique Values Count': nunique,
                'Unique Values': unique_values_str  # Store as a string
            })

        unique_df = pd.DataFrame(unique_info)

 
        
        # Display the DataFrame
        st.subheader("Unique Values Analysis")
        st.write(unique_df)

    if st.session_state.get('data') is not None:
        df = st.session_state['data']
        st.success("Dataset loaded successfully!")

        # Stacked Bar Chart for Null and Non-Null Values (Columns with Nulls Only)
        null_counts = df.isnull().sum()
        if null_counts.sum() > 0:
            st.subheader("Percentage of Null and Non-Null Values (Columns with Nulls Only)")

            # Filter for columns with null counts > 0
            columns_with_nulls = null_counts[null_counts > 0].index
            total_rows = df.shape[0]
            null_percentage = (null_counts[columns_with_nulls] / total_rows) * 100
            non_null_percentage = 100 - null_percentage

            stacked_data = pd.DataFrame({
                'Column': columns_with_nulls,
                'Null Percentage': null_percentage.values,
                'Non-Null Percentage': non_null_percentage.values
            })

            fig = go.Figure()

            # Add bars for null percentages
            fig.add_trace(go.Bar(
                x=stacked_data['Column'],
                y=stacked_data['Null Percentage'],
                name='Null Percentage',
                marker=dict(color='red'),
                hovertemplate='Column: %{x}<br>%{y:.2f}% Null<extra></extra>'
            ))

            # Add bars for non-null percentages
            fig.add_trace(go.Bar(
                x=stacked_data['Column'],
                y=stacked_data['Non-Null Percentage'],
                name='Non-Null Percentage',
                marker=dict(color='green'),
                hovertemplate='Column: %{x}<br>%{y:.2f}% Non-Null<extra></extra>'
            ))

            fig.update_layout(
                title="Stacked Bar Chart of Null and Non-Null Values (Columns with Nulls)",
                xaxis_title="Columns",
                yaxis_title="Percentage (%)",
                barmode='stack',
                xaxis=dict(tickangle=45),
                legend=dict(title="Legend")
            )
            st.plotly_chart(fig)
        else:
            st.write("No null values are present in the dataset.")

        # Stacked Bar Chart for Label Proportions Across Categorical Columns
        # st.subheader("Label Proportions Across Categorical Columns")

        # Filter categorical columns
        categorical_columns = df.select_dtypes(include=['object', 'category']).columns

    if st.session_state.get('data') is not None:
        df = st.session_state['data']
        # st.success("Dataset loaded successfully!")

        # Filter categorical columns with <= 30 unique values
        categorical_columns = [
            col for col in df.select_dtypes(include=['object', 'category']).columns
            if df[col].nunique() <= 50
        ]

        if categorical_columns:
            st.subheader("Proportions of Unique Labels (Including Nulls) Across Categorical Columns")

            # Prepare a DataFrame to hold the stacked percentages
            stacked_data = []

            for col in categorical_columns:
                # Calculate the value counts including NaN as a separate label
                col_counts = df[col].value_counts(dropna=False)
                col_percentages = (col_counts / len(df)) * 100

                # Append to the stacked_data list
                for label, percentage in col_percentages.items():
                    stacked_data.append({
                        'Feature': col,
                        'Label': str(label) if pd.notna(label) else 'Null',  # Treat NaN as 'Null'
                        'Percentage': percentage
                    })

            # Convert to a DataFrame
            stacked_data_df = pd.DataFrame(stacked_data)

            # Create the stacked bar chart
            fig = go.Figure()
            # st.write(stacked_data_df['Label'].unique())
            for label in stacked_data_df['Label'].unique():
                label_data = stacked_data_df[stacked_data_df['Label'] == label]
                fig.add_trace(go.Bar(
                    x=label_data['Feature'],
                    y=label_data['Percentage'],
                    name=str(label),
                    customdata=label_data['Label'],  # Pass the Label data as customdata
                    hovertemplate=(
                        '<b>Feature:</b> %{x}<br>'
                        '<b>Label:</b> %{customdata}<br>'  # Use customdata for Label
                        '<b>Percentage:</b> %{y:.2f}%<extra></extra>'
                    )
                ))


            fig.update_layout(
                title="Stacked Bar Chart of Label Proportions (Including Nulls) Across Categorical Columns",
                xaxis_title="Features",
                yaxis_title="Percentage (%)",
                barmode='stack',
                xaxis=dict(tickangle=45),
                legend=dict(title="Labels")
            )
            st.plotly_chart(fig)
        else:
            st.write("No categorical columns with ≤ 30 unique values are present in the dataset.")

# Run the Streamlit app
if __name__ == "__main__":
    page1()
