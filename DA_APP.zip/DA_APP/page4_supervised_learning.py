import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, roc_curve, mean_squared_error, confusion_matrix, roc_auc_score
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt

def page4():
    st.title("Supervised Learning")

    # Ensure dataset is uploaded
    if 'data' not in st.session_state or st.session_state['data'] is None:
        st.warning("Please upload a dataset first.")
        return

    df = st.session_state['data']
    
    # Display dataset preview
    st.subheader("Dataset Preview")
    st.write(df.head())

    # Handle missing values
    df = handle_missing_values(df)

    # Convert non-numeric columns to numeric using LabelEncoder
    df = convert_categorical_to_numeric(df)

    # Select features and target
    feature_cols = st.multiselect("Select Feature Columns", df.columns)
    target_col = st.selectbox("Select Target Column", df.columns)
    
    if not feature_cols or not target_col:
        st.warning("Please select both features and target column.")
        return

    # Get the unique values in the target column
    y = df[target_col]
    
    # Identify if y is categorical, ordinal, or continuous
    if y.dtype == 'object' or len(y.unique()) < 20:
        model_type = 'Classification'
    elif len(y.unique()) <= 10:  # Possible ordinal target
        model_type = 'Ordinal Classification or Regression'
    else:
        model_type = 'Regression'

    # Display the appropriate model options
    if model_type == 'Classification':
        model_type = st.radio("Choose Model Type", ['Classification'])
        model = get_classification_model()
        y_pred = train_and_evaluate_classification(model, df[feature_cols], y)
    elif model_type == 'Ordinal Classification or Regression':
        model_type = st.radio("Choose Model Type", ['Ordinal Classification', 'Ordinal Regression'])
        model = get_classification_model() if model_type == 'Ordinal Classification' else get_regression_model()
        y_pred = train_and_evaluate_classification(model, df[feature_cols], y) if model_type == 'Ordinal Classification' else train_and_evaluate_regression(model, df[feature_cols], y)
    elif model_type == 'Regression':
        model_type = st.radio("Choose Model Type", ['Regression'])
        model = get_regression_model()
        y_pred = train_and_evaluate_regression(model, df[feature_cols], y)

    # Save predictions
    save_predictions(y, y_pred)

    # Plot Correlation Map
    plot_correlation_map(df, feature_cols, target_col)

def handle_missing_values(df):
    # Fill missing values
    for col in df.columns:
        if df[col].isnull().any():
            if df[col].dtype in ['float64', 'int64']:
                df[col].fillna(df[col].mean(), inplace=True)
            else:
                df[col].fillna(df[col].mode()[0], inplace=True)
    return df

def convert_categorical_to_numeric(df):
    # Apply LabelEncoder to convert non-numeric columns to numeric
    label_encoder = LabelEncoder()
    
    for column in df.columns:
        if df[column].dtype == 'object':  # Check if column is categorical
            df[column] = label_encoder.fit_transform(df[column])
    
    return df

def get_classification_model():
    model_type = st.selectbox("Select Classification Model", ['Logistic Regression', 'Random Forest'])
    if model_type == 'Logistic Regression':
        return LogisticRegression(max_iter=1000)
    elif model_type == 'Random Forest':
        return RandomForestClassifier()

def train_and_evaluate_classification(model, X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Evaluation metrics
    accuracy = accuracy_score(y_test, y_pred)
    st.write(f"Accuracy: {accuracy:.4f}")
    
    cm = confusion_matrix(y_test, y_pred)
    st.subheader("Confusion Matrix")
    
    # Plot confusion matrix using fig
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax)
    st.pyplot(fig)

    # Ensure ROC curve is calculated only for binary classification
    if len(y_test.unique()) == 2:  # Check if the classification is binary
        fpr, tpr, _ = roc_curve(y_test, model.predict_proba(X_test)[:, 1])
        auc = roc_auc_score(y_test, y_pred)
        st.write(f"ROC-AUC: {auc:.4f}")
        
        # Plot ROC curve using fig
        fig, ax = plt.subplots()
        ax.plot(fpr, tpr, label=f'AUC = {auc:.4f}')
        ax.plot([0, 1], [0, 1], linestyle='--')
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.legend(loc="lower right")
        st.pyplot(fig)
    else:
        st.warning("ROC-AUC is only applicable for binary classification. Please select a binary target variable.")
    
    return y_pred

def get_regression_model():
    model_type = st.selectbox("Select Regression Model", ['Linear Regression', 'Random Forest'])
    if model_type == 'Linear Regression':
        return LinearRegression()
    elif model_type == 'Random Forest':
        return RandomForestRegressor()

def train_and_evaluate_regression(model, X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    r2 = model.score(X_test, y_test)
    st.write(f"Mean Squared Error: {mse:.4f}")
    st.write(f"R² Score: {r2:.4f}")

    # Plot Actual vs Predicted using fig
    fig, ax = plt.subplots()
    ax.scatter(y_test, y_pred)
    ax.set_xlabel('Actual')
    ax.set_ylabel('Predicted')
    ax.set_title('Actual vs Predicted')
    st.pyplot(fig)

    return y_pred

def save_predictions(y_test, y_pred):
    if st.checkbox("Save Predictions"):
        predictions = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
        predictions.to_csv('predictions.csv', index=False)
        st.success("Predictions saved as 'predictions.csv'.")

def plot_correlation_map(df, feature_cols, target_col):
    st.subheader("Correlation Map")
    
    # Select only the features and target for correlation
    selected_cols = feature_cols + [target_col]
    correlation_matrix = df[selected_cols].corr()
    
    # Plot correlation heatmap
    fig, ax = plt.subplots()
    sns.heatmap(correlation_matrix, annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
    st.pyplot(fig)
