import streamlit as st
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.cluster.hierarchy import linkage

def page5():
    st.title("Unsupervised Learning: PCA and Clustering with Null Value Handling")

    # Check if data is available
    if 'data' not in st.session_state or st.session_state['data'] is None:
        st.warning("Please upload data on Page 1 before proceeding.")
        return

    # Load data
    df = st.session_state['data'].copy()

    st.subheader("Step 1: Handle Missing Values")

    # Count null values
    null_counts = df.isnull().sum()
    st.write("Null value counts for each column:")
    st.write(null_counts.sort_values(ascending=False))

    # Drop columns with more than 33% null values
    threshold = 0.33 * len(df)
    cols_to_drop = null_counts[null_counts > threshold].index
    if not cols_to_drop.empty:
        st.write(f"Dropping columns with more than 33% missing values: {list(cols_to_drop)}")
        df.drop(columns=cols_to_drop, inplace=True)

    # Fill null values in remaining columns
    for col in df.columns:
        if df[col].dtype in [np.float64, np.int64]:  # Numerical columns
            df[col].fillna(df[col].mean(), inplace=True)
        else:  # Categorical columns
            df[col].fillna(df[col].mode()[0], inplace=True)

    st.write("Data after handling missing values:")
    st.write(df.head())

    st.subheader("Step 2: Convert Categorical Columns to Numerical")
    # Label Encoding for categorical columns
    label_encoders = {}
    for col in df.select_dtypes(include='object').columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le
    st.write("Categorical columns have been converted to numerical.")

    st.subheader("Step 3: Standardization")
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df)
    st.write("Data has been standardized.")

    st.subheader("Step 4: Principal Component Analysis (PCA)")

    pca_checkbox = st.checkbox("Run PCA")
    if pca_checkbox:
        # Automatically calculate the recommended number of components for 95% explained variance
        pca_temp = PCA()
        pca_temp.fit(scaled_data)
        cumulative_explained_variance = np.cumsum(pca_temp.explained_variance_ratio_)

        # Find the number of components required to cover more than 95% of the variance
        suggested_n_components = np.argmax(cumulative_explained_variance >= 0.95) + 1

        st.write(f"Suggested number of components for >95% explained variance: {suggested_n_components}")

        # Slider for selecting the number of components (with default as suggested_n_components)
        n_components = st.slider(
            "Select Number of Principal Components",
            min_value=1,
            max_value=min(df.shape[1], 10),
            value=suggested_n_components,
        )

        # User options for visualization
        plot_option = st.radio(
            "Choose Visualization Type for PCA:",
            ("2D Plot", "3D Plot", "Both")
        )

        # Button to trigger PCA computation and plotting
        if st.button("Run PCA"):
            pca = PCA(n_components=n_components)
            pca_result = pca.fit_transform(scaled_data)

            # Generate 2D plot if selected
            if plot_option in ("2D Plot", "Both"):
                st.write("2D Plot of PCA Results:")
                fig2d, ax2d = plt.subplots()
                ax2d.scatter(pca_result[:, 0], pca_result[:, 1], c='blue', alpha=0.7)
                ax2d.set_xlabel("Principal Component 1")
                ax2d.set_ylabel("Principal Component 2")
                ax2d.set_title("PCA 2D Scatter Plot")
                st.pyplot(fig2d)

            # Generate 3D plot if selected
            if plot_option in ("3D Plot", "Both") and n_components >= 3:
                st.write("3D Plot of PCA Results:")
                fig3d = plt.figure(figsize=(8, 6))
                ax3d = fig3d.add_subplot(111, projection='3d')
                ax3d.scatter(
                    pca_result[:, 0], pca_result[:, 1], pca_result[:, 2], c='green', alpha=0.7
                )
                ax3d.set_xlabel("Principal Component 1")
                ax3d.set_ylabel("Principal Component 2")
                ax3d.set_zlabel("Principal Component 3")
                ax3d.set_title("PCA 3D Scatter Plot")
                st.pyplot(fig3d)

            # Explained Variance Ratio Plot
            st.write("Explained Variance Ratio Plot:")
            fig_ev, ax_ev = plt.subplots(figsize=(8, 4))
            ax_ev.bar(range(1, n_components + 1), pca.explained_variance_ratio_, alpha=0.7, color='blue')
            ax_ev.set_xlabel("Principal Component")
            ax_ev.set_ylabel("Explained Variance Ratio")
            ax_ev.set_title("Explained Variance Ratio for PCA Components")
            st.pyplot(fig_ev)

    # Step 5: K-Means Clustering
    st.subheader("Step 5: K-Means Clustering")

    kmeans_checkbox = st.checkbox("Run K-Means Clustering")
    if kmeans_checkbox:
        # Select number of clusters for K-Means
        n_clusters = st.slider("Select Number of Clusters", min_value=2, max_value=10, value=3)

        # Choose PCA components and visualization options
        plot_option = st.radio(
            "Choose K-Means Visualization Type:",
            ("2D Plot", "3D Plot", "Both")
        )

        # Button to trigger K-Means clustering and PCA visualization
        if st.button("Run K-Means Clustering"):
            # Automatically set number of components based on the selected plot option
            if plot_option == "2D Plot":
                pca_components = 2
            else:
                pca_components = 3  # If both, we will show 3D plot and generate 2D as well

            # Apply PCA for dimensionality reduction
            pca = PCA(n_components=pca_components)  # Reduce the data to 2 or 3 components
            pca_result = pca.fit_transform(scaled_data)  # PCA-reduced data

            # Apply K-Means to the PCA-transformed data
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            kmeans_labels = kmeans.fit_predict(pca_result)  # Clustering on the PCA-reduced data

            # Get the cluster centers in the reduced space
            cluster_centers = kmeans.cluster_centers_

            st.write("K-Means Clustering Results (on PCA-transformed data):")

            # 2D Plot for PCA with 2 components
            if plot_option in ("2D Plot", "Both") and pca_components >= 2:
                st.write("2D Plot of K-Means Clustering:")
                fig2d, ax2d = plt.subplots()
                scatter = ax2d.scatter(pca_result[:, 0], pca_result[:, 1], c=kmeans_labels, cmap='viridis', alpha=0.7)

                # Add a color legend to indicate different clusters
                legend1 = ax2d.legend(*scatter.legend_elements(), title="Clusters")
                ax2d.add_artist(legend1)

                # Plot the cluster centers
                ax2d.scatter(
                    cluster_centers[:, 0], cluster_centers[:, 1], c='red', marker='X', s=200, label='Cluster Centers'
                )

                # Set labels and title
                ax2d.set_xlabel("Principal Component 1")
                ax2d.set_ylabel("Principal Component 2")
                ax2d.set_title(f"K-Means Clustering (on PCA-reduced data)")
                st.pyplot(fig2d)

            # 3D Plot for PCA with 3 components
            if plot_option in ("3D Plot", "Both") and pca_components >= 3:
                st.write("3D Plot of K-Means Clustering:")
                fig3d = plt.figure(figsize=(8, 6))
                ax3d = fig3d.add_subplot(111, projection='3d')

                ax3d.scatter(pca_result[:, 0], pca_result[:, 1], pca_result[:, 2], c=kmeans_labels, cmap='viridis', alpha=0.7)

                # Add cluster centers to 3D plot
                ax3d.scatter(
                    cluster_centers[:, 0], cluster_centers[:, 1], cluster_centers[:, 2],
                    c='red', marker='X', s=200, label='Cluster Centers'
                )

                # Set labels and title
                ax3d.set_xlabel("Principal Component 1")
                ax3d.set_ylabel("Principal Component 2")
                ax3d.set_zlabel("Principal Component 3")
                ax3d.set_title(f"K-Means Clustering (on PCA-reduced data)")

                st.pyplot(fig3d)


    st.subheader("Step 6: Hierarchical Clustering with Clustermap")
    if st.checkbox("Perform Hierarchical Clustering"):
        linkage_method = st.selectbox(
            "Select Linkage Method for Hierarchical Clustering",
            ["ward", "complete", "average", "single"]
        )

        # Option for using a subset of data
        if len(scaled_data) > 1000:
            st.warning("Dataset is large. Performing hierarchical clustering on a subset of 1000 samples.")
            subset_data = scaled_data[:1000]
        else:
            subset_data = scaled_data

        # Hierarchical clustering with seaborn clustermap
        try:
            st.write("Hierarchical Clustering Heatmap:")
            sns.clustermap(subset_data, method=linkage_method, cmap='viridis', figsize=(10, 8))
            st.pyplot()
        except MemoryError:
            st.error("MemoryError: Dataset is too large for hierarchical clustering. Reduce the data size or sample fewer rows.")
