import streamlit as st
import pandas as pd
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt

# Function to fill missing values based on the dtype of each feature
def fill_missing_values(df):
    for column in df.columns:
        if df[column].dtype == 'object':  # Categorical columns
            df[column].fillna(df[column].mode()[0], inplace=True)  # Fill with mode
        else:  # Numeric columns
            df[column].fillna(df[column].mean(), inplace=True)  # Fill with mean for numeric features
    return df

# Function to handle plotting logic for 1D plots (interactive)
def plot_1d(df, feature):
    # Check the type of the feature (numeric or categorical)
    dtype = df[feature].dtype
    
    if pd.api.types.is_numeric_dtype(dtype):
        plot_options = ['Box Plot', 'KDE with Histogram', 'Histogram']
        plot_type = st.selectbox("Select Plot Type", plot_options)
        
        if plot_type == 'Box Plot':
            fig = px.box(df, y=feature, title=f'Box Plot of {feature}')
            fig.update_traces(marker=dict(color='skyblue'))
            fig.update_layout(xaxis_title='', yaxis_title=feature)
            st.plotly_chart(fig)

        elif plot_type == 'KDE with Histogram':
            # Create the KDE with histogram using Seaborn's histplot
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.histplot(df[feature], kde=True, ax=ax)
            ax.set_title(f'{feature} with KDE')
            ax.set_xlabel(feature)
            ax.set_ylabel('Density')
            st.pyplot(fig)  # Display the plot with Streamlit's st.pyplot()

        elif plot_type == 'Histogram':
            fig = px.histogram(df, x=feature, nbins=30, title=f'Histogram of {feature}')
            fig.update_layout(xaxis_title=feature, yaxis_title='Frequency')
            st.plotly_chart(fig)
    
    else:
        plot_options = ['Pie Chart', 'Count Plot']
        plot_type = st.selectbox("Select Plot Type", plot_options)
        
        if plot_type == 'Pie Chart':
            pie_data = df[feature].value_counts()
            fig = px.pie(pie_data, values=pie_data.values, names=pie_data.index, title=f'Pie Chart of {feature}')
            st.plotly_chart(fig)

        elif plot_type == 'Count Plot':
            # Fix the issue here by renaming the columns after reset_index()
            count_data = df[feature].value_counts().reset_index()
            count_data.columns = [feature, 'count']  # Rename columns for proper plotting
            fig = px.bar(count_data, x=feature, y='count', title=f'Count Plot of {feature}')
            fig.update_layout(xaxis_title=feature, yaxis_title='Count')
            st.plotly_chart(fig)

# Function to handle plotting logic for 2D plots (interactive)
def plot_2d(df, feature_x, feature_y):
    x_dtype = df[feature_x].dtype
    y_dtype = df[feature_y].dtype

    if x_dtype == 'object' and y_dtype == 'object':
        plot_options = ['Bar Plot', 'Stacked Bar Plot', 'Heatmap', 'Count Plot']
    elif pd.api.types.is_numeric_dtype(x_dtype) and pd.api.types.is_numeric_dtype(y_dtype):
        plot_options = ['Scatter Plot', 'Line Plot', 'Hexbin Plot', 'Density Plot']
    elif (x_dtype == 'object' and pd.api.types.is_numeric_dtype(y_dtype)) or (y_dtype == 'object' and pd.api.types.is_numeric_dtype(x_dtype)):
        plot_options = ['Box Plot', 'Violin Plot', 'Swarm Plot', 'Bar Plot', 'Point Plot']
    else:
        plot_options = ['Please select valid features for plotting']

    plot_type = st.selectbox("Select Plot Type", plot_options)

    if plot_type == 'Bar Plot':
        fig = px.bar(df, x=feature_x, y=feature_y, title=f'Bar Plot of {feature_x} vs {feature_y}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

    elif plot_type == 'Scatter Plot':
        fig = px.scatter(df, x=feature_x, y=feature_y, title=f'Scatter Plot of {feature_x} vs {feature_y}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

    elif plot_type == 'Line Plot':
        fig = px.line(df, x=feature_x, y=feature_y, title=f'Line Plot of {feature_x} vs {feature_y}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

    elif plot_type == 'Box Plot':
        fig = px.box(df, x=feature_x, y=feature_y, title=f'Box Plot of {feature_y} by {feature_x}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

    elif plot_type == 'Violin Plot':
        fig = px.violin(df, x=feature_x, y=feature_y, title=f'Violin Plot of {feature_y} by {feature_x}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

    elif plot_type == 'Hexbin Plot':
        fig = px.density_heatmap(df, x=feature_x, y=feature_y, title=f'Hexbin Plot of {feature_x} vs {feature_y}')
        fig.update_layout(xaxis_title=feature_x, yaxis_title=feature_y)
        st.plotly_chart(fig)

# Function to handle plotting logic for 3D plots (interactive)
def plot_3d(df, feature_x, feature_y, feature_z):
    fig = px.scatter_3d(df, x=feature_x, y=feature_y, z=feature_z, title=f'3D Scatter Plot of {feature_x}, {feature_y}, and {feature_z}')
    fig.update_layout(
        scene=dict(
            xaxis_title=feature_x,
            yaxis_title=feature_y,
            zaxis_title=feature_z
        )
    )
    st.plotly_chart(fig)

# Main function for feature selection and learning
def page7():
    st.title("Feature Selection and Learning")

    if st.session_state.get('data') is None:
        st.warning("Please upload a dataset first.")
        return
    
    df = st.session_state['data']
    
    # Fill missing values before plotting
    df = fill_missing_values(df)
    
    # Option to select plot type: 1D, 2D, or 3D
    plot_type = st.selectbox("Select Plot Dimension", ['1D Plot', '2D Plot', '3D Plot'])
    
    features = df.columns.tolist()

    if plot_type == '1D Plot':
        feature = st.selectbox("Select Feature for 1D Plot", features)
        # Handle plotting for 1D
        plot_1d(df, feature)
    
    elif plot_type == '2D Plot':
        feature_x = st.selectbox("Select X-axis feature", features)
        feature_y = st.selectbox("Select Y-axis feature", features)
        # Generate 2D plot
        plot_2d(df, feature_x, feature_y)
    
    elif plot_type == '3D Plot':
        feature_x = st.selectbox("Select X-axis feature", features)
        feature_y = st.selectbox("Select Y-axis feature", features)
        feature_z = st.selectbox("Select Z-axis feature", features)
        # Generate 3D plot
        plot_3d(df, feature_x, feature_y, feature_z)
