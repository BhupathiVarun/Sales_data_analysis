import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

def page3():
    st.title("Data Preprocessing")

    # Ensure data is available in session state
    if 'data' not in st.session_state or st.session_state['data'] is None:
        st.warning("Please upload data on Page 1 before proceeding.")
        return  # Exit function if data is not available

    # Load DataFrame from session state
    df = st.session_state['data'].copy()  # Create a copy to avoid modifying original data

    # Display initial dataframe preview
    st.write("Perform preprocessing here:")
    st.write(df.head())

    # Initialize lists for tracking columns filled with mean, median, or mode
    if 'mean_filled_cols' not in st.session_state:
        st.session_state['mean_filled_cols'] = []
    if 'median_filled_cols' not in st.session_state:
        st.session_state['median_filled_cols'] = []
    if 'mode_filled_cols' not in st.session_state:
        st.session_state['mode_filled_cols'] = []

    # Check if there are any null values
    if df.isnull().values.any():
        st.write("Your dataset contains null values.")

        # Step 1: Select columns to fill null values
        user_choice = st.radio(
            "How would you like to handle null values for the correlation heatmap?",
            ("Remove null values", "Keep null values with custom filling")
        )

        if user_choice == "Remove null values":
            # Button to confirm removal of null values
            if st.button("Submit to Remove Null Values"):
                # Remove rows with null values
                df = df.dropna()
                st.success("Null values removed from the dataset.")

        elif user_choice == "Keep null values with custom filling":
            # Automatically fill categorical columns with mode
            categorical_cols = [col for col in df.select_dtypes(include=['object', 'category']).columns if df[col].isnull().any()]
            for col in categorical_cols:
                df[col].fillna(df[col].mode()[0], inplace=True)
                st.session_state['mode_filled_cols'].append(col)
                st.success(f"Automatically filled null values in '{col}' with Mode.")

            # Allow user to select numerical columns and choose mean or median
            numerical_cols = [col for col in df.select_dtypes(include=[np.number]).columns if df[col].isnull().any()]

            if numerical_cols:
                selected_col = st.selectbox("Select a numerical column with null values", numerical_cols)

                if selected_col:
                    fill_choice = st.radio(f"Choose fill method for '{selected_col}'", ("Mean", "Median"))

                    # Apply the selected fill method for the chosen column
                    if st.button(f"Apply {fill_choice} fill to '{selected_col}'"):
                        if fill_choice == "Mean":
                            st.session_state['mean_filled_cols'].append(selected_col)
                            df[selected_col].fillna(df[selected_col].mean(), inplace=True)
                            st.success(f"Filled null values in '{selected_col}' with Mean.")
                        elif fill_choice == "Median":
                            st.session_state['median_filled_cols'].append(selected_col)
                            df[selected_col].fillna(df[selected_col].median(), inplace=True)
                            st.success(f"Filled null values in '{selected_col}' with Median.")

    # Convert categorical columns to numeric using label encoding
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns
    for col in categorical_cols:
        df[col] = pd.Categorical(df[col]).codes

    # Generate Correlation Heatmap button
    if st.button("Generate Correlation Heatmap"):
        try:
            # Compute correlation matrix
            df_corr = df.corr()
            
            # Remove columns and rows that have all zeros or NaNs (excluding self-correlation)
            mask = ~((df_corr.abs() < 0.01) | df_corr.isna()).all()
            df_corr_filtered = df_corr.loc[mask, mask]
            
            # Create hover text
            hover_text = [[f'Row: {row}<br>Column: {col}<br>Correlation: {val:.2f}' 
                          for col, val in df_corr_filtered[row].items()] 
                         for row in df_corr_filtered.index]

            # Create heatmap using plotly
            fig = go.Figure(data=go.Heatmap(
                z=df_corr_filtered.values,
                x=df_corr_filtered.columns,
                y=df_corr_filtered.index,
                hoverongaps=False,
                hoverinfo='text',
                text=hover_text,
                colorscale='RdBu',  # Red-Blue diverging colorscale
                zmid=0,  # Center the colorscale at 0
                colorbar=dict(
                    title='Correlation',
                    titleside='right'
                )
            ))

            # Update layout
            fig.update_layout(
                title='Correlation Heatmap',
                width=800,  # Width in pixels
                height=800,  # Height in pixels
                xaxis=dict(
                    tickangle=45,
                    side='bottom'
                ),
                yaxis=dict(
                    tickangle=0
                ),
                xaxis_showgrid=False,
                yaxis_showgrid=False,
                showlegend=False
            )

            # Display the plot in Streamlit
            st.plotly_chart(fig)
            
            # Display filtered correlation matrix as a table
            st.write("Filtered Correlation Matrix:")
            st.write(df_corr_filtered)
            
            # Display removed columns
            removed_cols = set(df_corr.columns) - set(df_corr_filtered.columns)
            if removed_cols:
                st.write("Removed columns (due to no significant correlations):")
                st.write(list(removed_cols))
            
        except Exception as e:
            st.error(f"Error generating heatmap: {str(e)}")